package com.ig;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.ig.beans.WishMessageGenerator;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	//locate xml file
    	FileSystemResource fis = new FileSystemResource("src\\main\\java\\com\\ig\\resources\\applicationContext.xml");
    	 // creation and activation of container
        BeanFactory factory = new XmlBeanFactory(fis);
       WishMessageGenerator wmg =  (WishMessageGenerator)factory.getBean("wmg");
       wmg.getMessage(" : Aniket");
        
       
        
        
    }
}
